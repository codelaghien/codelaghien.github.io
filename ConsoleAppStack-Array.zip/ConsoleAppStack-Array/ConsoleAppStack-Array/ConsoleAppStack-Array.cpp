/*
	Ten: ...
	Lop: ...
	Project: ....
	.....
*/
#include <iostream>
#include <conio.h> 
#include <string>
#include <time.h> 
#include <algorithm>
#include <windows.h> 
#include "MyWindows.h";
#include "Stack.cpp";
#include "Queue.h";
#include "Node.h";
using namespace std;

#define WIDTH  100
#define HEIGHT 30

#define BLACK			0
#define BLUE			1
#define GREEN			2
#define CYAN			3
#define RED				4
#define MAGENTA			5
#define BROWN			6
#define LIGHTGRAY		7
#define DARKGRAY		8
#define LIGHTBLUE		9
#define LIGHTGREEN		10
#define LIGHTCYAN		11
#define LIGHTRED		12
#define LIGHTMAGENTA	13
#define YELLOW			14
#define WHITE			15

int option(MyWindows input) {
	input.clearConsole();
	input.drawFrame();
	input.Write(" Menu ", 2, 0, GREEN, WHITE);

	// Stack
	input.Write("1. Push a random number", 2, 2, GREEN, WHITE);
	input.Write("2. Pop ", 2, 3, GREEN, WHITE);
	input.Write("3. Peek", 2, 4, GREEN, WHITE);
	input.Write("4. Is Empty?", 2, 5, GREEN, WHITE);
	input.Write("5. Is Full?", 2, 6, GREEN, WHITE);
	input.Write("6. Print Stack", 2, 7, GREEN, WHITE);

	// Queue
	/*input.Write("1. Enqueue a random number", 2, 2, GREEN, WHITE);
	input.Write("2. Dequeue ", 2, 3, GREEN, WHITE);
	input.Write("3. Front", 2, 4, GREEN, WHITE);
	input.Write("4. Is Empty?", 2, 5, GREEN, WHITE);
	input.Write("5. Is Full?", 2, 6, GREEN, WHITE);
	input.Write("6. Print Stack", 2, 7, GREEN, WHITE);*/

	input.Write("7. Exit", 2, 8, GREEN, WHITE);
	input.Write("Chon option: ", 2, 10, GREEN, WHITE);
	input.gotoXY(15, 10);
	int op;
	cin >> op;
	return op;
} 

int main()
{   
	srand(time(NULL));

	MyWindows console(5, 1, 60, 21, BLUE, WHITE);
	console.clearConsole();
	console.drawFrame();
	console.Write(" Stack - Array ", 2, 0, BLUE, WHITE);

	MyWindows error(5, 24, 60, 5, RED, WHITE);
	error.clearConsole();
	error.drawFrame();
	error.Write(" Thong Bao ", 2, 0, RED, WHITE);

	Stack<Node> stack;
	Queue queue;
	MyWindows input(67, 1, 30, 15, GREEN, WHITE);
	bool done = false;
	Node node;
	while (!done)
	{
		int op = option(input);
		console.clearConsole();
		switch (op) {
			case 1:
				node = Node("T" + to_string((rand() % 100) + 1), (rand() % 100) + 1, "Nam"); // 0 to 99 
				//stack.push(n);
				// queue.enqueue(n)
				if (stack.push(node))
				{ 
					console.Write(node.getData() + " da them va`o stack", 2, 1, BLUE, WHITE);
				}
				else
				{
					console.Write("Stack is full", 2, 1, BLUE, WHITE);
				}

				console.Write("Stack:", 2, 2, BLUE, WHITE);
				console.Write(stack.getData(), 2, 3, BLUE, WHITE);
				break;
			case 2:
				// stack.pop
				// queue.dequeue(&n)
				if (stack.pop(&node))
				{
					console.Write("Pop ra gia tri la`: " + node.getData(), 2, 1, BLUE, WHITE);
					console.Write("Stack:", 2, 2, BLUE, WHITE);
					console.Write(stack.getData(), 2, 3, BLUE, WHITE);
				}
				else
				{
					console.Write("Stack is empty", 2, 1, BLUE, WHITE);
				}  
				break;
			case 3:
				//n = stack.peek();
				// queue.front(&n)
				if (stack.peek(&node))
				{
					console.Write("Peek ra gia tri la`: " + node.getData(), 2, 1, BLUE, WHITE);
				}
				else {
					console.Write("Stack is empty", 2, 1, BLUE, WHITE);
				}

				console.Write("Stack:", 2, 2, BLUE, WHITE);
				console.Write(stack.getData(), 2, 3, BLUE, WHITE);
				break;
			case 4: 
				if (stack.isEmpty()) {
					console.Write("Stack is empty", 2, 1, BLUE, WHITE);
				}
				else
				{
					console.Write("Stack is not empty", 2, 1, BLUE, WHITE);
				}
				break;
			case 5: 
				if (stack.isFull()) {
					console.Write("Stack is full", 2, 1, BLUE, WHITE);

					console.Write("Stack:", 2, 2, BLUE, WHITE);
					console.Write(stack.getData(), 2, 3, BLUE, WHITE);
				}
				else
				{
					console.Write("Stack is not full", 2, 1, BLUE, WHITE);
				}
				break;
			case 6: 
				console.Write("Stack:", 2, 1, BLUE, WHITE);
				//console.Write(stack.getData(), 2, 2, BLUE, WHITE);
				console.Write(stack.getData(), 2, 2, BLUE, WHITE);
				break;
			case 7:
				done = true;
				break;
		}
	}

	/*cout << endl << endl;
	cout << "Nhan bat ky phim nao de ket thuc chuong trinh";*/
	//char c = _getch();
}