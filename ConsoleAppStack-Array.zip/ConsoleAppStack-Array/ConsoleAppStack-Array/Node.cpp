#include "Node.h"

Node::Node()
{
	_Name = "";
	_Age = 0;
	_Gender = "";
}
Node::Node(string name, int age, string gender)
{
	_Name = name;
	_Age = age;
	_Gender = gender;
}
Node::~Node()
{

}

string Node::getData()
{
	//return _Name + " (" + to_string(_Age) + ") (" + _Gender + ")";
	return _Name;
}