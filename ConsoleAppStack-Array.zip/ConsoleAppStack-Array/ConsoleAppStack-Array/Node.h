#pragma once
#include <string>
using namespace std;

class Node
{
	private:
		string _Name = "";
		int _Age = 0;
		string _Gender = "";

	public:
		Node();
		Node(string name, int age, string gender);
		~Node();

		string getData();
};

