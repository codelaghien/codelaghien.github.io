#include "Queue.h"
#include <string> 

Queue::Queue()
{
	_Queue = new int[MAX_SIZE];
}
Queue::~Queue()
{
	delete[] _Queue;
}

bool Queue::enqueue(int n)
{
	if (isFull()) return false;
	_Queue[_Tail] = n;
	_Count++;
	_Tail++;
	if (_Tail > MAX_SIZE) _Tail = 0;
	return true;
}
bool Queue::dequeue(int* n)
{
	if (isEmpty()) return false;
	*n = _Queue[_Head];
	_Count--;
	_Head++;
	if (_Head > MAX_SIZE) _Head = 0;
	return true;
}
bool Queue::front(int* n)
{
	if (isEmpty()) return false;
	*n = _Queue[_Head];
	return true;
}
bool Queue::isEmpty()
{
	return (_Count == 0);
}
bool Queue::isFull()
{
	return (_Count == MAX_SIZE);
}
string Queue::getData()
{
	string st = "";
	for (int i = 0; i < _Count; i++) {
		int index = i + _Head;
		if (index > MAX_SIZE) index = 0;
		st += to_string(_Queue[index]) + " ";
	}
	return st;
}