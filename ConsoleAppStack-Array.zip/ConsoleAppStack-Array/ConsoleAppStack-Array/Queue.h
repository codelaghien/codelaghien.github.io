#pragma once
#include <string>
using namespace std;

class Queue
{
private:
	const int MAX_SIZE = 4;
	int _Head = 0;
	int _Tail = 0;
	int _Count = 0;
	int* _Queue;
public:
	Queue();
	~Queue();

	bool enqueue(int n);
	bool dequeue(int* n);
	bool front(int* n);
	bool isEmpty();
	bool isFull();
	string getData();
};

