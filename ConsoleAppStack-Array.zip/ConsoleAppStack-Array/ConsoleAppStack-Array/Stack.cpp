#include "Stack.h"
#include <string> 
#include <typeinfo>

template <class T>
Stack<T>::Stack() {
	_AvailableIndex = 0;
	_Stack = new T[MAX_SIZE];
}
template <class T>
Stack<T>::~Stack()
{
	delete[] _Stack;
}
template <class T>
bool Stack<T>::push(T node)
{
	if (isFull()) return false;
	_Stack[_AvailableIndex] = node;
	_AvailableIndex++;
	return true;
}
template <class T>
bool Stack<T>::pop(T* node)
{
	if (isEmpty()) return false;
	_AvailableIndex--; 
	*node = _Stack[_AvailableIndex];
	return true;
}
template <class T>
bool Stack<T>::peek(T* node)
{
	if (isEmpty()) return 0;
	*node = _Stack[_AvailableIndex - 1];
	return true;
}
template <class T>
bool Stack<T>::isEmpty()
{
	return (_AvailableIndex == 0);
}
template <class T>
bool Stack<T>::isFull()
{
	return (_AvailableIndex >= MAX_SIZE);
}
template <class T>
string Stack<T>::getData()
{
	string st = "";
	for (int i = 0; i < _AvailableIndex; i++)
	{ 
		//int value = _Stack[i];
		//st += to_string(value) + " ";
		st += _Stack[i].getData() + " ";
	}
	return st;
}
