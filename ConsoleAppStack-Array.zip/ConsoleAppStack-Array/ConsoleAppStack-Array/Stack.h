#pragma once
#include <string>
using namespace std;

template <class T>
class Stack
{ 
	private:
		const int MAX_SIZE = 100;
		int _AvailableIndex = 0;
		T* _Stack;
	public:
		Stack();
		~Stack();

		bool push(T node);
		bool pop(T* node);
		bool peek(T* node);
		bool isEmpty();
		bool isFull();
		string getData();
};

